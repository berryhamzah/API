package com.swift.apidev;


import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.UUID;

// ==========================================
//you can use the following single Java class to:

// 1. Load the .cer
// 2. Load the .pk8
// 3. Validate the key pair
// 4. Generate the JWT assertion
// 5. Request the OAuth token from SWIFT
// 6. Print the access token response

// ==========================================

public class Main {

    
    // ==========================================
    // CONFIGURATION
    // ==========================================

    private static final String CERT_FILE = "public-cert.cer";
    private static final String PRIVATE_KEY_FILE = "private-key.pk8";       
    private static final String TRUST_STORE_FILE = "berry-hamzah-3.jks"; // this contain root CA, to be used for SSL handshake with api-test.swiftnet.sipn.swift.com
    private static final String CONSUMER_KEY = "VqBBQpjA8DtAH2w92EWFjZvcBHDiGW0U";
    private static final String CONSUMER_SECRET = "qq0ZrbpMqdvuLa3Q";
    private static final String API_GATEWAY = "api-test.swiftnet.sipn.swift.com";
    private static final String OAUTH_URL = "api-test.swiftnet.sipn.swift.com/oauth2/v1/token";
    private static final String SCOPE = "swift.alliancecloud.api!p/access_to_service";

    // ==========================================



    public static void main(String[] args) {
        System.out.println("Simple Code to get OAuth token!");
        
        try {
            System.out.println("****************************************");
            System.out.println("Consumer Key: " + CONSUMER_KEY);
            System.out.println("Consumer Secret: " + CONSUMER_SECRET);
            System.out.println("API Gateway: " + API_GATEWAY);
            System.out.println("OAuth URL: " + OAUTH_URL);
            System.out.println("Scope: " + SCOPE);
            System.out.println("Certificate File: " + CERT_FILE);
            System.out.println("Private Key File: " + PRIVATE_KEY_FILE);

            System.out.println("****************************************");
            System.out.println("1. Load the .cer file and print the certificate details");
            System.out.println("Loading certificate...");
            X509Certificate certificate = loadCertificate(CERT_FILE);

            System.out.println("====Certificate loaded: " + certificate.getSubjectDN());
            System.out.println("====Certificate issuer: " + certificate.getIssuerDN());
            System.out.println("====Certificate serial number: " + certificate.getSerialNumber());
            System.out.println("====Certificate expiration date: " + certificate.getNotAfter());
            System.out.println("====Certificate encoded: " + Base64.getEncoder().encodeToString(certificate.getEncoded()));
            
            System.out.println("****************************************");

            System.out.println("2. Load the private key and print the key details");
            System.out.println("Loading private key...");
            PrivateKey privateKey = loadPrivateKey(PRIVATE_KEY_FILE);
            
            System.out.println("====Private key loaded: " + privateKey.getAlgorithm());
            System.out.println("====Private key format: " + privateKey.getFormat());
            System.out.println("====Private key encoded: " + Base64.getEncoder().encodeToString(privateKey.getEncoded()));

            System.out.println("****************************************");
            System.out.println("3. Validate the key pair");
            System.out.println("Validating key pair...");
            validateKeyPair(certificate, privateKey);

            System.out.println("****************************************");
        
            System.out.println("4. Build the JWT assertion");
            String jwt = buildJwt(
                            certificate,
                            privateKey,
                            CONSUMER_KEY,
                            OAUTH_URL);

            System.out.println("\nJWT Generated Successfully\n");
            System.out.println("JWT: " + jwt);
            

            System.out.println("****************************************");
            System.out.println("5. Request the OAuth token from SWIFT");
            String tokenResponse = requestAccessToken(jwt);

            System.out.println("\nOAuth Response:");
            System.out.println(tokenResponse);

            System.out.println("****************************************");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==========================================
    // 1. LOAD X509 CERTIFICATE
    // ==========================================

    private static X509Certificate loadCertificate(String certPath) throws Exception {

        CertificateFactory cf = CertificateFactory.getInstance("X.509");

        try (InputStream is = Main.class.getClassLoader().getResourceAsStream(certPath)) {
            if (is == null) {
                throw new FileNotFoundException("Resource not found: " + certPath);
            }
            return (X509Certificate) cf.generateCertificate(is);
        }
    }

    
    // ==========================================
    // 2. LOAD PKCS8 PRIVATE KEY
    // ==========================================

    private static PrivateKey loadPrivateKey(
            String keyFile) throws Exception {

        InputStream is = Main.class.getClassLoader().getResourceAsStream(keyFile);
        if (is == null) {
            throw new FileNotFoundException("Resource not found: " + keyFile);
        }

        String key = new String(is.readAllBytes(), StandardCharsets.UTF_8);

        key = key.replace(
                        "-----BEGIN PRIVATE KEY-----",
                        "")
                .replace(
                        "-----END PRIVATE KEY-----",
                        "")
                .replaceAll("\\s", "");

        byte[] keyBytes =
                Base64.getDecoder()
                        .decode(key);

        PKCS8EncodedKeySpec spec =
                new PKCS8EncodedKeySpec(keyBytes);

        KeyFactory factory =
                KeyFactory.getInstance("RSA");

        return factory.generatePrivate(spec);
    }

    
    // ==========================================
    // 3. VERIFY KEY PAIR
    // ==========================================

    private static void validateKeyPair(
            X509Certificate cert,
            PrivateKey privateKey)
            throws Exception {

        byte[] challenge =
                "SWIFT".getBytes(
                        StandardCharsets.UTF_8);

        Signature signer =
                Signature.getInstance(
                        "SHA256withRSA");

        signer.initSign(privateKey);
        signer.update(challenge);

        byte[] signature =
                signer.sign();

        Signature verifier =
                Signature.getInstance(
                        "SHA256withRSA");

        verifier.initVerify(cert);

        verifier.update(challenge);

        boolean valid =
                verifier.verify(signature);

        if (!valid) {
            throw new RuntimeException(
                    "Certificate and private key DO NOT match");
        }

        System.out.println(
                "Certificate and private key match");
    }

    
    // ==========================================
    // 4. BUILD JWT - Generate JWT assertion using the certificate and private key
    // ==========================================

    private static String buildJwt(
            X509Certificate cert,
            PrivateKey privateKey,
            String consumerKey,
            String audience)
            throws Exception {

        long iat =
                System.currentTimeMillis() / 1000;

        long exp =
                iat + 300;

        String certificateBase64 =
                Base64.getEncoder()
                        .encodeToString(
                                cert.getEncoded());

        String channelDn =
                cert.getSubjectX500Principal()
                        .getName();

        String headerJson =
                "{"
                        + "\"typ\":\"JWT\","
                        + "\"alg\":\"RS256\","
                        + "\"x5c\":[\""
                        + certificateBase64
                        + "\"]"
                        + "}";
        
        System.out.println("====JWT Header: " + headerJson);

        String payloadJson =
                "{"
                        + "\"iss\":\"" + consumerKey + "\","
                        + "\"sub\":\"" + channelDn + "\","
                        + "\"aud\":\"" + audience + "\","
                        + "\"jti\":\"" + UUID.randomUUID() + "\","
                        + "\"iat\":" + iat + ","
                        + "\"exp\":" + exp
                        + "}";

        System.out.println("====JWT Payload: " + payloadJson);

        String header =
                Base64.getUrlEncoder()
                        .withoutPadding()
                        .encodeToString(
                                headerJson.getBytes(
                                        StandardCharsets.UTF_8));
        
        System.out.println("====JWT Header Base64: " + header);

        String payload =
                Base64.getUrlEncoder()
                        .withoutPadding()
                        .encodeToString(
                                payloadJson.getBytes(
                                        StandardCharsets.UTF_8));
        
        System.out.println("====JWT Payload Base64: " + payload);

        String signingInput =
                header + "." + payload;
        
        System.out.println("====JWT Signing Input: header.payload : " + signingInput);

        Signature signature =
                Signature.getInstance(
                        "SHA256withRSA");

        signature.initSign(privateKey);
        
        signature.update(
                signingInput.getBytes(
                        StandardCharsets.UTF_8));
        
        System.out.println("====JWT Signature: " + signature);

        String jwtSignature =
                Base64.getUrlEncoder()
                        .withoutPadding()
                        .encodeToString(
                                signature.sign());
        
        System.out.println("====JWT Signature Base64: " + jwtSignature);
        System.out.println("====JWT Complete: Return signingInput.jwtSignature for JWT assertion : " + signingInput + "." + jwtSignature);
        return signingInput
                + "."
                + jwtSignature;
    }

        // ==========================================
        // Load JKS file for SSL handshake with api-test.swiftnet.sipn.swift.com    
        // ==========================================

        private static SSLContext createSSLContext() throws Exception {
                KeyStore trustStore =
                KeyStore.getInstance("JKS");
                try (InputStream is =
                        Main.class.getClassLoader().getResourceAsStream(TRUST_STORE_FILE)) 
                                {
                                if (is == null) {
                                throw new FileNotFoundException(TRUST_STORE_FILE + " not found");
                                }
                        trustStore.load(is,"Abcd1234".toCharArray());
                }

        TrustManagerFactory tmf =
            TrustManagerFactory.getInstance(
                    TrustManagerFactory.getDefaultAlgorithm());

        tmf.init(trustStore);

        SSLContext sslContext =
                SSLContext.getInstance("TLS");

        sslContext.init(
                null,
                tmf.getTrustManagers(),
                null);

        return sslContext;
        }



    // ==========================================
    // 5. REQUEST TOKEN
    // ==========================================

    private static String requestAccessToken(
            String jwt)
            throws Exception {

        String formBody =
                "grant_type="
                        + URLEncoder.encode(
                        "urn:ietf:params:oauth:grant-type:jwt-bearer",
                        "UTF-8")
                        + "&scope="
                        + URLEncoder.encode(
                        SCOPE,
                        "UTF-8")
                        + "&assertion="
                        + jwt;

        String  oatuthUrl = "https://" + OAUTH_URL;
        System.out.println("Calling: " + oatuthUrl);
        
        
SSLContext sslContext =   createSSLContext();


        URL url = new URL(oatuthUrl);

        HttpsURLConnection conn =
                (HttpsURLConnection)
                        url.openConnection();

                        
conn.setSSLSocketFactory(sslContext.getSocketFactory());


        conn.setRequestMethod("POST");
        conn.setDoOutput(true);

        String basicAuth =
                Base64.getEncoder()
                        .encodeToString(
                                (CONSUMER_KEY + ":" + CONSUMER_SECRET)
                                        .getBytes(StandardCharsets.UTF_8));

        conn.setRequestProperty(
                "Authorization",
                "Basic " + basicAuth);

        conn.setRequestProperty(
                "Content-Type",
                "application/x-www-form-urlencoded");

        conn.setRequestProperty(
                "Accept",
                "application/json");

        try (OutputStream os =
                     conn.getOutputStream()) {

            os.write(
                    formBody.getBytes(
                            StandardCharsets.UTF_8));
        }

        int responseCode =
                conn.getResponseCode();

        InputStream stream =
                responseCode == 200
                        ? conn.getInputStream()
                        : conn.getErrorStream();

        return new String(
                stream.readAllBytes(),
                StandardCharsets.UTF_8);
    }




}



